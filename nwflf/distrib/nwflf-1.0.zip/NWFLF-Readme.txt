For comlete documentation of this script, please head over to:
http://www.nextwish.org/nwflf.shtml