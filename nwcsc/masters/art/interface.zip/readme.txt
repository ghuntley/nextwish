CS-Nation Stu_pid artwork CS overhaul.

Ok you guys..now extract this file to your Directory wherever you have HL..so if you have it in your c:\sierra\half-life\cstrike directory the point the zip to c:\sierra and it will unzip it. And if you have your directory named something else like HL then I'm sorry you'll hafta unzip the files to a dummy directory then move them to your cstrike directory, it's the easiest way I could see to zip all these files up. 

Anyways remember that these include Stu_pid's first image as the splash screen and his fourth one as the console screen. 


I'd like to thanks Stu_pid for making the kick ass images, cowwie for helpin me figure out how the fak to work qlumpy, and gho$talker for hooking me up with his already done grey fonts for the splash menus. Thanks you guys...

--Scud(mhuertas@mica.edu)