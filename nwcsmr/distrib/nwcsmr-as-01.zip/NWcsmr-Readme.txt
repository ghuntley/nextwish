For comlete documentation of this addon, please head over to:
http://nextwish.qgl.org/nwcsmr.shtml