For comlete documentation of this Counter-Strike Addon, please head over to:
http://nextwish.qgl.org/nwcsnude.shtml