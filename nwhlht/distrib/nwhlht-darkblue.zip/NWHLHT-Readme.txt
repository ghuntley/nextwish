For comlete documentation and installation instructions of this HUD Text Color Repleacement, please head over to:
http://users.bigpond.net.au/nextwish/nwhlht.htm