For comlete documentation and installation instructions of this HUD Text Color Repleacement, please head over to:
http://nextwish.qgl.org/nwhlht.shtml