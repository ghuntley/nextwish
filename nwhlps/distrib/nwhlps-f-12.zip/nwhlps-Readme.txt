Enjoy these ladies, but don't get caught looking at them for too long, you could go blind (from a flash bang of course)!

slomo@wealwayswin.com
www.wealwayswin.com

The image was taken from a newsgroup
converted using IrfanView32
then turned into a .wad with Wally

I learned how to do this from www.hardwarepub.com/articles/colorlogos

Thanks to Nextwish for providing an outlet for this file, check there for more pr0n and much, much, more half-life shtuff!

www.nextwish.org