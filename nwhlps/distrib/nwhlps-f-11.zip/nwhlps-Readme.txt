For comlete documentation of this mod, please head over to:
http://nextwish.qgl.org